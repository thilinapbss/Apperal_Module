/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["./SortFlex","./ColumnFlex","./ConditionFlex","./GroupFlex","./AggregateFlex","./xConfigFlex"],(e,o,r,d,t,a)=>{"use strict";return{hideControl:"default",unhideControl:"default",addColumn:o.createAddChangeHandler(),removeColumn:o.createRemoveChangeHandler(),moveColumn:o.createMoveChangeHandler(),removeSort:e.removeSort,addSort:e.addSort,moveSort:e.moveSort,addCondition:r.addCondition,removeCondition:r.removeCondition,removeGroup:d.removeGroup,addGroup:d.addGroup,moveGroup:d.moveGroup,removeAggregate:t.removeAggregate,addAggregate:t.addAggregate,setColumnWidth:a.createSetChangeHandler({aggregation:"columns",property:"width"})}});
//# sourceMappingURL=Table.flexibility.js.map