/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(()=>{"use strict";const t={NotValidated:"NotValidated",Validated:"Validated"};return t},true);
//# sourceMappingURL=ConditionValidated.js.map